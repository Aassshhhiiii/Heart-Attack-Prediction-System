import mysql.connector
from tkinter import messagebox

def Save_Data_Mysql(B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R ):
    try:
        mydb = mysql.connector.connect(host='localhost', user='root', password="Aashi@2101")
        mycursor = mydb.cursor()
        print("Connection established!")
        
    except mysql.connector.Error as err:
        messagebox.showerror("Connection Error", "Database connection not established!!")
        
    try: 
        command="create database Heart_Data"
        mycursor.execute(command)
        
        command= "use Heart_Data"
        mycursor.execute(command)
        
        command="create table data (user int auto_increment key not null, Name varchar(50), Date varchar(50),DOB varchar(100),age varchar(100), sex varchar(100),Cp varchar(100),trestbps varchar(100),chol varchar(100),restecg varchar(100),thalach varchar(100),exang varchar(100),oldpeak varchar(100), slope varchar(100),ca varchar(100),thal varchar(100),result varchar(100))"
        mycursor.execute(command)
        
        command= "insert into data(Name, Date, DOB, age, sex, Cp, trestbps, chol, fbs, restecg,thalach,exang,oldpeak,slope,ca,thal,Result) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        mycursor.execute(command,(B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R))
        mydb.commit()
        mydb.close()
        messagebox.showinfo("Register","New user added sucessfully!!!!  ")
  
    except:
        pass

        mycursor.execute("use Heart_Data")
        mydb=mysql.connector.connect(host='localhost',user='root',password="Aashi@2101",database='Heart_Data')
        mycursor=mydb.cursor()

Save_Data_Mysql('mr unknown', "16/04/2024", "1979", "44", "1", "1", "233", "233" ,"1", "1", "233", "1", "233.0", "0", "2", "1", "0")
# import mysql.connector
# from tkinter import messagebox

# def connect_to_database():
#     try:
#         mydb = mysql.connector.connect(host='localhost', user='root', password="Aashi@2101")
#         print("Connection established!")
#         return mydb
#     except mysql.connector.Error as err:
#         messagebox.showerror("Connection Error", f"Database connection not established: {err}")
#         return None

# def create_database_and_table(mycursor):
#     try:
#         mycursor.execute("CREATE DATABASE IF NOT EXISTS Heart_Data")
#         mycursor.execute("USE Heart_Data")
        
#         mycursor.execute("""CREATE TABLE IF NOT EXISTS data (
#                             user INT AUTO_INCREMENT PRIMARY KEY,
#                             Name VARCHAR(50),
#                             Date VARCHAR(50),
#                             DOB VARCHAR(100),
#                             age VARCHAR(100),
#                             sex VARCHAR(100),
#                             Cp VARCHAR(100),
#                             trestbps VARCHAR(100),
#                             chol VARCHAR(100),
#                             restecg VARCHAR(100),
#                             thalach VARCHAR(100),
#                             exang VARCHAR(100),
#                             oldpeak VARCHAR(100),
#                             slope VARCHAR(100),
#                             ca VARCHAR(100),
#                             thal VARCHAR(100),
#                             result VARCHAR(100)
#                             )""")
#         print("Database and table created successfully!")
#     except mysql.connector.Error as err:
#         messagebox.showerror("Error", f"An error occurred: {err}")

# def save_data_to_database(mycursor, mydb, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R):
#     try:
#         command = "INSERT INTO data(Name, Date, DOB, age, sex, Cp, trestbps, chol, restecg, thalach, exang, oldpeak, slope, ca, thal, result) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
#         mycursor.execute(command, (B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R))
#         mydb.commit()
#         mydb.close()
#         messagebox.showinfo("Register", "New user added successfully!")
#     except mysql.connector.Error as err:
#         messagebox.showerror("Error", f"An error occurred: {err}")

# def Save_Data_Mysql(B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R):
#     mydb = connect_to_database()
#     if mydb:
#         mycursor = mydb.cursor()
#         create_database_and_table(mycursor)
#         save_data_to_database(mycursor, mydb, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R)

# Save_Data_Mysql('mr unknown', "16/04/2024", "1979", "44", "1", "1", "233", "233" ,"1", "1", "233", "1", "233.0", "0", "2", "1", "0")
